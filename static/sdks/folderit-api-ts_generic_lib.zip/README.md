
# Getting Started with Folderit API

## Introduction

### Changes

#### 2025.08.24 - 2.0.71

* Permission properties now support narrowing with the `fields` parameter.

#### 2025.08.22 - 2.0.70

* Automatically expand requested fields, expand parameter is not required for the fields listed under the expanded variants
* Add `thumbnails` property to File and FileVersion schemas

#### 2025.08.21 - 2.0.69

* Add extension filter to [entities by parent](#tag/Entity/operation/getEntitiesByParent), [entities by tag](#tag/Entity/operation/getEntitiesByTag) and [all entities](#tag/Entity/operation/getAllEntities)

#### 2025.08.12 - 2.0.68

* Add `parentUid` query parameter to [Recycled entities](#tag/Entity/operation/getRecycledEntities)

#### 2025.08.11 - 2.0.67

* Add `position` as an expandable field to a team user

#### 2025.08.10 - 2.0.66

* Alter [Team users](#tag/Account/operation/getTeamUsers) endpoint to a paginated response, add groups as an expandable field to a team user

#### 2025.07.31 - 2.0.65

* Add lockId to [Lock a file](#tag/File/operation/lockFilePost) request  
  Unlocking is supported only with a [PUT request](#tag/File/operation/unlockFile2)

#### 2025.07.29 - 2.0.64

* Add teamUserStatus field to [account users](#tag/Account/operation/getAccountUsers) and status field to [account team users](#tag/Account/operation/getTeamUsers)

#### 2025.07.24 - 2.0.63

* Add an optional operator to the search filter filterItem->number

#### 2025.07.01 - 2.0.62

* Add account stats expandable field

#### 2025.06.10 - 2.0.61

* Add paginated response variants to [reminder listings](#tag/Reminder)
* Add recurrence property to [update a Reminder](#tag/Reminder/operation/updateReminder)

#### 2025.06.04 - 2.0.60

* Add a method to [empty the recycle bin](#tag/Entity/operation/emptyRecycleBin)

#### 2025.06.03 - 2.0.59

* Add the size property to [file versions](#tag/File/operation/getFileVersions)
* Add a paginated response variant to [file versions listing](#tag/File/operation/getFileVersions)
* Fetch multiple entities by UID at [Sections/entities](#tag/Entity/operation/getEntities)
* [Duplication of entities](#tag/Entity/operation/duplicateEntities)
* Add a paginated response variant to [related entities listing](#tag/Entity/operation/getEntityRelatedItems)

#### 2025.05.26 - 2.0.58

* Add operationId to all paths

#### 2025.04.17 - 2.0.57

* Add method property to resolution workflow audit trail data property

#### 2025.04.06 - 2.0.56

* Add 2 new paths for fetching tags, add pagination and sorting to existing tag listing
  * [Get only root tags](#tag/Tag/operation/getRootTags)
  * [Get sub-tags](#tag/Tag/operation/getSubTags)
* Add [Search entities](#tag/Search/operation/searchEntities) endpoint

#### 2025.04.02 - 2.0.55

* Add [resolutions](#tag/Resolution) and [workflows](#tag/Workflow)
* Add resolutionSupport extendable property to Entity

#### 2025.03.27 - 2.0.54

* Add `options` as an expandable field to Meta

#### 2025.03.26 - 2.0.53

* Add [entities by tag](#tag/Entity/operation/getEntitiesByTag) endpoint

#### 2025.02.03 - 2.0.52

* Add more granular permissions for account sharing

#### 2025.01.20 - 2.0.51

* Add `recurrence` property to reminders

#### 2025.01.17 - 2.0.50

* Add `time` property to file lock requests for custom lock duration

#### 2024.12.09 - 2.0.49

* Add `source` field to retention for customizing the source attribute for calculating the retention end time

#### 2024.11.13 - 2.0.48

* Add `accountWatermarking` audit trail event

#### 2024.11.13 - 2.0.47

* Add `timeFormat` as expandable field to User

#### 2024.10.25 - 2.0.46

* Added comment field for workflow responses in audit trail

#### 2024.10.10 - 2.0.45

* Added accountTeamUserManagedInvite, accountTeamUserManagedInviteDelete, accountTeamUserManagedAccept and accountTeamUserManagedReject audit trail events

#### 2024.09.17 - 2.0.44

* Deprecate Account file report [`GET /v2/accounts/{accountUid}/reports/file-list`](#tag/File/operation/getAccountFileReport)

#### 2024.09.10 - 2.0.43

* Meta of type `float` is renamed from Float to Decimal, type field stays the same for compatibility.  
  Value is represented as a string for compatibility with higher precisions and larger values.
* Change asic entity type text representation from `asic` to `file`
* Add prefix and wildcard search operators for meta filters

#### 2024.09.02 - 2.0.42

* Add `language` to the composable filter of search

#### 2024.09.02 - 2.0.41

* Add an expandable field `activeUser` to audit trails. Present, when a substitute user performed the action.

#### 2024.07.26 - 2.0.40

* File and folder retention audit events contain no `data` property any more on removal of retention
* Add `cause` to audit trails to mark actions performed by background processes. Initially the only option is `retention`.
* Add all entities listing endpoint: [`GET /v2/accounts/{accountUid}/entities/all`](#tag/Entity/operation/getAllEntities)

#### 2024.06.14 - 2.0.39

* Mark inbox and team folders as nullable fields for Account

#### 2024.05.27 - 2.0.38

* Fix Audit trail sync-log id field value
* Add `sort` and `viewType` expandable fields to Folder

#### 2024.05.23 - 2.0.37

* Search: add `uid` to queryFilter list

#### 2024.04.26 - 2.0.36

* Add `visibleColumnsWithMeta` as expandable field to Folder to get meta columns with names

#### 2024.04.18 - 2.0.35

* Add `remoteUsername` as expandable field to Team user

#### 2024.04.16 - 2.0.34

* Add redirect Location url in content as well
* Add `creator` as expandable field to Entity
* Include response samples with all expanded fields.  
  Note: It is recommended to ask for as few fields as is necessary as there are optimizations in place in the background for generating responses. This goes for both default fields and extra related data using expand option. For example, when requesting for all entities under a parent with tags, meta etc, if You don't need to have permissions for each related piece, do not request for them. A sample get param would be: `?fields=uid,name,tags.uid,tags.name,meta.meta.uid,meta.value&expand=tags,meta:myMetaUid,meta:myOtherMetaUid`

#### 2024.04.11 - 2.0.33

* Add sorting to entities by parent endpoint: [`GET /v2/accounts/{accountUid}/entities/{entityUid}/entities`](#tag/Entity/operation/getEntitiesByParent)
* Add `extension` as expandable field to Entity
* Add `size` as expandable field to Entity

#### 2024.04.10 - 2.0.32

* Update folder column attribute options list
* Add `tags` as expandable field to Entity
* Add `dateFormat` as expandable field to User

#### 2024.03.20 - 2.0.31

* Add `meta:UID` expand field to entities

#### 2024.03.18 - 2.0.30

* Get a list of parents for an entity: [`GET /v2/accounts/{accountUid}/entities/{entityUid}/parents`](#tag/Entity/operation/getEntityParents)
* Add isRoot property to entity

#### 2024.03.11 - 2.0.29

* Add sectionOrder property to entity and folder models (applicable to only root entities/sections)
* Add folderStats property to entity and folder models
* Add inboxFolder and teamFolder properties to entity and folder models

#### 2024.01.09 - 2.0.28

* Add account as an expandable relation to Entity

#### 2023.11.24 - 2.0.27

* Add highlight expand field for search results

#### 2023.11.22 - 2.0.26

* Add `version` expandable field to `File` objects

#### 2023.10.30 - 2.0.25

* Add fileUpdateContent and fileUpdateOnline permissions to file
* Add canShareCustomPermissions to Account permissions list
  * Without this permission, You can only set the role property for a share, no settings

#### 2023.10.22 - 2.0.24

* Add endpoints for getting shares to a specific user
  * Get direct shares to a specific user: [`GET /v2/accounts/{accountUid}/users/{userUid}/shares`](#tag/Share/operation/getUserShares)
  * Get all shares (including through group memberships) accessible by a specific user: [`GET /v2/accounts/{accountUid}/users/{userUid}/access`](#tag/Share/operation/getAllUserShares)
* Add documentation for fetching share info: [`GET /v2/accounts/{accountUid}/shares/{shareUid}`](#tag/Share/operation/getShare)
* Add settings property to shares

#### 2023.10.18 - 2.0.23

* Add missing endpoint documentation for tag sharing
  * Get tag shares: [`GET /v2/accounts/{accountUid}/tags/{tagUid}/shares`](#tag/Tag/operation/getTagShares)
  * Share a tag: [`POST /v2/accounts/{accountUid}/tags/{tagUid}/shares`](#tag/Tag/operation/addTagShares)

#### 2023.10.18 - 2.0.22

* Add group expand parameters to doc

#### 2023.09.20 - 2.0.21

* Add composable filter and scoring option to file/folder searches
  * *filter* property can contain a nested set of familiar filters to create a required composite set of filters
  * *scoring* property is used to force scoring even when we're not doing search by query directly (only filtering)  
    Scoring results are not guaranteed to be sensible

#### 2023.09.19 - 2.0.20

* Added fileOnlineView and fileOnlineEdit audit trail events

#### 2023.09.14 - 2.0.19

* Sections list is now available for partially accessible accounts, canGetSections property indicates that all sections are guaranteed to be accessible
* Share items to user by userUid

#### 2023.09.03 - 2.0.18

* Enable moving tags around

#### 2023.08.30 - 2.0.17

* Add `isUsed` attribute to Meta Select Option
* Add tag management to entities for a single point to manage tags for all types of entities
* Tag sharing
* Add tagUid filter to file/folder search endpoints

#### 2023.08.10 - 2.0.16

* Add searchAfter field to file/folder search endpoints for paging over more than 10000 results.

#### 2023.07.31 - 2.0.15

* Add sorting to file/folder search endpoints

#### 2023.03.05 - 2.0.14

* Reminders for all types of entities
  * Added two endpoints, one specifically for folders, other for any type of entity
  * Folders: [`GET /v2/accounts/{accountUid}/folders/{folderUid}/reminders`](#tag/Reminder/operation/getFolderReminders)
  * Entities: [`GET /v2/accounts/{accountUid}/entities/{entityUid}/reminders`](#tag/Reminder/operation/getEntityReminders)
* Related items to all types of entities of all types
  * Added two endpoints, one specifically for folders, other for any type of entity
  * Folders: [`GET /v2/accounts/{accountUid}/folders/{folderUid}/related`](#tag/Folder/operation/getFolderRelatedItems)
  * Entities: [`GET /v2/accounts/{accountUid}/entities/{entityUid}/related`](#tag/Entity/operation/getEntityRelatedItems)
* Meta for all items, new endpoint is under entities: [`GET /v2/accounts/{accountUid}/entities/{entityUid}/meta`](#tag/Entity/operation/getEntityMeta)

#### 2023.02.21 - 2.0.13

* Add new request header `X-Folderit-Request-Key` to make it possible to differentiate audit trails resulting from your own requests
* Add audit trail endpoint tailored for file syncing: [`GET /v2/accounts/{accountUid}/audit/syncLog`](#tag/Audit/operation/getFileSyncLog)
* Add `extra` field to the expand list of folder and entity, which gives access to number, note, date etc.
* Add `extra` field to folder and entity update endpoints

#### 2023.01.23 - 2.0.12

* Add includeFiles, includeLinks and includeFolders fields for FolderMeta

#### 2022.07.22 - 2.0.11

* Add groups as group members ([GET group all members](#operation/getGroupMembers))
* Add [Entity endpoint](#tag/Entity) for a unified access to directory structure (access to all types of entities like folders, files, links and more in the future)

#### 2022.04.13 - 2.0.10

* Add `fields` and `expand` query parameters to paths resulting in accounts, folders and files
  * `fields` parameter can be used to reduce amount of data returned. For example: `fields=uid,name`
  * `expand` parameter can be used to fetch related objects with the request, for example fetching meta with a file list.
    * [`GET /v2/accounts/{accountUid}/folders/{folderUid}/files?expand=meta,people,tags`](#tag/Folder/operation/getFilesByParent) includes meta, people and tags arrays with each file
  * `expand` and `fields` can be combined to get all fields of the initial object, but only a few from a related object:
    * `fields=*,meta.value,meta.meta.name&expand=meta`
* Search result updates for autocomplete [`GET /v2/accounts/{accountUid}/search/simple`](#tag/Search/operation/searchAutocomplete) and [`GET /v2/accounts/{accountUid}/search/files`](#tag/Search/operation/searchFiles):
  * Mark file search result pathUid property as deprecated
  * Add mimeType property to file search results

#### 2022.04.06 - 2.0.9

* Add email as a required field for signing up team users via [`POST /v2/accounts/{accountUid}/team-users`](#tag/Account/operation/addTeamUser)

#### 2022.04.02 - 2.0.8

* Add new audit events
  * fileDuplicate
  * folderDuplicate
  * folderSubfileDuplicate
  * folderSubfolderDuplicate
  * accountSectionDuplicate
* Add userUid and groupUid to Audit Trail Share data
* Audit trail fileDownload events now have fileVersionUid data

#### 2022.02.23 - 2.0.7

* Add folder import emails (mailInAddress)
  * Activate an address for importing mails to any folder (in contrast to Inbox section, which always has a static address)
    * Activate address: [`POST /v2/accounts/{accountUid}/folders/{folderUid}/email`](#tag/Folder/operation/configureFolderEmail)
    * Deactivate existing address: [`DELETE /v2/accounts/{accountUid}/folders/{folderUid}/email`](#tag/Folder/operation/deleteFolderEmail)
    * Reset (active or deleted) address to get a new random key: [`PUT /v2/accounts/{accountUid}/folders/{folderUid}/email`](#tag/Folder/operation/requestNewFolderEmailAddress)
  * If You prefer to only use POST requests, use `action` parameter in request body

#### 2022.02.13 - 2.0.6

* Add dateFrom and dateTo filters for file search
* Add file report [`GET /v2/accounts/{accountUid}/reports/file-list`](#tag/File/operation/getAccountFileReport)

#### 2022.01.24 - 2.0.5

* Add new audit event: fileResolutionDelete

#### 2022.01.22 - 2.0.4

* Adjusted field names in error responses to correct names

#### 2022.01.16 - 2.0.3

* Added pagination
  * [`GET /v2/accounts/{accountUid}/folders/{folderUid}/folders`](#tag/Folder/operation/getFolderByParent)
  * [`GET /v2/accounts/{accountUid}/recycle-bin/folders`](#tag/Folder/operation/getRecycledFolders)
  * [`GET /v2/accounts/{accountUid}/recycle-bin/files`](#tag/File/operation/getRecycledFiles)

#### 2022.01.14 - 2.0.2

* Fix Folder visibleColumns meta column spec

#### 2022.01.14 - 2.0.1

* Added `page-size` parameter to paths that already had `page` parameter
  * [`GET /v2/accounts/{accountUid}/audit/accountLog`](#tag/Audit/operation/getAccountRecentAuditTrail)
  * [`GET /v2/accounts/{accountUid}/audit`](#tag/Audit/operation/getAccountAuditTrail)
  * [`GET /v2/accounts/{accountUid}/files/{fileUid}/audit`](#tag/Audit/operation/getFileAuditTrail)
  * [`GET /v2/accounts/{accountUid}/folders/{folderUid}/audit`](#tag/Audit/operation/getFolderAuditTrail)
  * [`GET /v2/accounts/{accountUid}/groups`](#tag/Group/operation/getGroups)
* Added pagination
  * [`GET /v2/accounts/{accountUid}/folders/{folderUid}/files`](#tag/File/operation/getFilesByParent)
* Added missing pagination documentation
  * [`GET /v2/accounts/{accountUid}/groups/{groupUid}/users`](#tag/Group/operation/getGroupUsers)

#### 2021.12.19 - 2.0.0

API v2 comes with multiple breaking changes. Most notably:

* Removed any reference to object `ID`s. Instead we are now using `UID`s. UIDs are globally unique and have a data type of CHAR(10)
* Paths now include `accountUid` as required parameter
* `accountId` paramater has been removed from request body parameters as `accountUid` is now always part of the path parameters for Account-related requests
* New tags and people/signees can be created directly without attaching them to a file from [`POST /v2/accounts/{accountUid}/tags`](#tag/Tag/operation/addTag) and [`POST /v2/accounts/{accountUid}/people`](#tag/Person/operation/addPerson)
* Removed deprecated paths and parameters

##### New features

* Audit trail: added new tag and person/signee events on Account level
  * tagNew
  * tagDelete
  * tagName
  * signeeNew
  * signeeDelete
  * signeeName
* Search
  * Added queryFilter options to File search
    * number
    * mailSubject
    * mailSenderEmail
    * mailSenderName
    * mailContent
  * Added filter fields to File search
    * number
    * mailSubject
    * mailSenderEmail
    * mailSenderName
    * mailContent

##### Detailed changes to paths:

* Removed paths:
  * /files
  * /files/{fileId}
  * /folders
  * /folders/{folderId}
  * /accounts/{accountId}/recycle-bin
  * /meta/{metaId}
  * /files/search
  * /folders/search
  * /download
  * /audit/files/{fileId}
  * /audit/folders/{folderId}
* New paths:
  * /v2/accounts/{accountUid}/files/{fileUid}/preview
  * /v2/accounts/{accountUid}/files/{fileUid}/versions/{fileVersionUid}/download
* Changed paths:
  * /files/upload -> /v2/accounts/{accountUid}/files/upload
  * /files/single/{fileId} -> /v2/accounts/{accountUid}/files/{fileUid}
  * /files/{fileId}/permissions -> /v2/accounts/{accountUid}/files/{fileUid}/permissions
  * /files/{fileId}/lock -> /v2/accounts/{accountUid}/files/{fileUid}/lock
  * /files/{fileId}/unlock -> /v2/accounts/{accountUid}/files/{fileUid}/unlock
  * /files/{fileId}/related -> /v2/accounts/{accountUid}/files/{fileUid}/related
  * /files/{fileId}/restore -> /v2/accounts/{accountUid}/files/{fileUid}/restore
  * /files/{fileId}/purge -> /v2/accounts/{accountUid}/files/{fileUid}/purge
  * /files/{fileId}/versions -> /v2/accounts/{accountUid}/files/{fileUid}/versions
  * /files/{fileId}/versions/{fileVersionId} -> /v2/accounts/{accountUid}/files/{fileUid}/versions/{fileVersionUid}
  * /files/download/{fileId} -> /v2/accounts/{accountUid}/files/{fileUid}/download
  * /files/versions/{fileVersionId}/preview -> /v2/accounts/{accountUid}/files/{fileUid}/versions/{fileVersionUid}/preview
  * /files/{fileId}/unpack -> /v2/accounts/{accountUid}/files/{fileUid}/unpack
  * /files/unpack-status/{key} -> /v2/accounts/{accountUid}/unpack/status/{key}
  * /files/unpack-check -> /v2/accounts/{accountUid}/unpack/check
  * /files/languages -> /v2/accounts/{accountUid}/document-languages
  * /folders/single/{folderId} -> /v2/accounts/{accountUid}/folders/{folderUid}
  * /files/people/{personId} -> /v2/accounts/{accountUid}/people/{personUid}
  * /files/people/{personId}/permissions -> /v2/accounts/{accountUid}/people/{personUid}/permissions
  * /folders/{folderId}/files -> /v2/accounts/{accountUid}/folders/{folderUid}/files
  * /folders/single/{folderId} -> /v2/accounts/{accountUid}/folders/{folderUid}
  * /folders/{folderId}/permissions -> /v2/accounts/{accountUid}/folders/{folderUid}/permissions
  * /folders/{folderId}/folders -> /v2/accounts/{accountUid}/folders/{folderUid}/folders
  * /folders/{folderId}/restore -> /v2/accounts/{accountUid}/folders/{folderUid}/restore
  * /folders/{folderId}/purge -> /v2/accounts/{accountUid}/folders/{folderUid}/purge
  * /groups/{groupId} -> /v2/accounts/{accountUid}/groups/{groupUid}
  * /groups/{groupId}/permissions -> /v2/accounts/{accountUid}/groups/{groupUid}/permissions
  * /groups/{groupId}/shares -> /v2/accounts/{accountUid}/groups/{groupUid}/shares
  * /groups/{groupId}/users -> /v2/accounts/{accountUid}/groups/{groupUid}/users
  * /groups/{groupId}/users/{userId} -> /v2/accounts/{accountUid}/groups/{groupUid}/users/{userUid}
  * /groups/{groupId}/users/{userId}/permissions -> /v2/accounts/{accountUid}/groups/{groupUid}/users/{userUid}/permissions
  * /meta/{metaId}/permissions -> /v2/accounts/{accountUid}/meta/{metaUid}/permissions
  * /files/{fileId}/meta -> /v2/accounts/{accountUid}/files/{fileUid}/meta
  * /files/{fileId}/meta/{metaId} -> /v2/accounts/{accountUid}/files/{fileUid}/meta/{metaUid}
  * /files/{fileId}/meta/active -> /v2/accounts/{accountUid}/files/{fileUid}/active-meta
  * /folders/{folderId}/meta -> /v2/accounts/{accountUid}/folders/{folderUid}/meta
  * /folders/{folderId}/meta/{metaId} -> /v2/accounts/{accountUid}/folders/{folderUid}/meta/{metaUid}
  * /folders/{folderId}/meta/active -> /v2/accounts/{accountUid}/folders/{folderUid}/active-meta
  * /files/people/{personId} -> /v2/accounts/{accountUid}/people/{personUid}
  * /files/people/{personId}/permissions -> /v2/accounts/{accountUid}/people/{personUid}/permissions
  * /files/{fileId}/people -> /v2/accounts/{accountUid}/files/{fileUid}/people
  * /files/{fileId}/people/{personId} -> /v2/accounts/{accountUid}/files/{fileUid}/people/{personUid}
  * /files/reminders/{reminderId} -> /v2/accounts/{accountUid}/reminders/{reminderUid}
  * /files/{fileId}/reminders -> /v2/accounts/{accountUid}/files/{fileUid}/reminders
  * /search/extensions -> /v2/accounts/{accountUid}/search/extensions
  * /search/files -> /v2/accounts/{accountUid}/search/files
  * /search/folders -> /v2/accounts/{accountUid}/search/folders
  * /search/simple -> /v2/accounts/{accountUid}/search/simple
  * /shares/{shareId} -> /v2/accounts/{accountUid}/shares/{shareUid}
  * /shares/{shareId}/permissions -> /v2/accounts/{accountUid}/shares/{shareUid}/permissions
  * /files/{fileId}/shares -> /v2/accounts/{accountUid}/files/{fileUid}/shares
  * /folders/{folderId}/shares -> /v2/accounts/{accountUid}/folders/{folderUid}/shares
  * /files/tags/{tagId} -> /v2/accounts/{accountUid}/tags/{tagUid}
  * /files/tags/{tagId}/permissions -> /v2/accounts/{accountUid}/tags/{tagUid}/permissions
  * /files/{fileId}/tags -> /v2/accounts/{accountUid}/files/{fileUid}/tags
  * /files/{fileId}/tags/{tagId} -> /v2/accounts/{accountUid}/files/{fileUid}/tags/{tagUid}
  * /audit/accountLog/{accountId} -> /v2/accounts/{accountUid}/audit/accountLog
  * /files/{fileId}/audit -> /v2/accounts/{accountUid}/files/{fileUid}/audit
  * /folders/{folderId}/audit -> /v2/accounts/{accountUid}/folders/{folderUid}/audit

## Building

### Requirements

The SDK relies on **Node.js** and **npm** (to resolve dependencies). It also requires **Typescript version >=4.1**. You can download and install Node.js and [npm](https://www.npmjs.com/) from [the official Node.js website](https://nodejs.org/en/download/).

> **NOTE:** npm is installed by default when Node.js is installed.

### Verify Successful Installation

Run the following commands in the command prompt or shell of your choice to check if Node.js and npm are successfully installed:

* Node.js: `node --version`

* npm: `npm --version`

![Version Check](https://apidocs.io/illustration/typescript?workspaceFolder=FolderIt&step=versionCheck)

### Install Dependencies

- To resolve all dependencies, go to the **SDK root directory** and run the following command with npm:

```bash
npm install
```

- This will install all dependencies in the **node_modules** folder.

![Resolve Dependencies](https://apidocs.io/illustration/typescript?workspaceFolder=FolderIt&workspaceName=folderit&step=resolveDependency)

## Installation

The following section explains how to use the generated library in a new project.

### 1. Initialize the Node Project

- Open an IDE/text editor for JavaScript like Visual Studio Code. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

- Click on **File** and select **Open Folder**. Select an empty folder of your project, the folder will become visible in the sidebar on the left.

![Open Folder](https://apidocs.io/illustration/typescript?step=openProject)

- To initialize the Node project, click on **Terminal** and select **New Terminal**. Execute the following command in the terminal:

```bash
npm init --y
```

![Initialize the Node Project](https://apidocs.io/illustration/typescript?step=initializeProject)

### 2. Add Dependencies to the Client Library

- The created project manages its dependencies using its `package.json` file. In order to add a dependency on the *FolderIt* client library, double click on the `package.json` file in the bar on the left and add the dependency to the package in it.

![Add Folderit Dependency](https://apidocs.io/illustration/typescript?workspaceFolder=FolderIt&workspaceName=folderit&step=importDependency)

- To install the package in the project, run the following command in the terminal:

```bash
npm install
```

![Install Folderit Dependency](https://apidocs.io/illustration/typescript?step=installDependency)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.Production`** |
| timeout | `number` | Timeout for API calls.<br>*Default*: `0` |
| httpClientOptions | [`Partial<HttpClientOptions>`](doc/http-client-options.md) | Stable configurable http client options. |
| unstableHttpClientOptions | `any` | Unstable configurable http client options. |
| logging | [`PartialLoggingOptions`](doc/partial-logging-options.md) | Logging Configuration to enable logging |
| openIdConnectCredentials | [`OpenIdConnectCredentials`](doc/auth/oauth-2-bearer-token.md) | The credential object for openIdConnect |
| oauthAuthorizationCodeCredentials | [`OauthAuthorizationCodeCredentials`](doc/auth/oauth-2-authorization-code-grant.md) | The credential object for oauthAuthorizationCode |
| oauthClientCredentialsCredentials | [`OauthClientCredentialsCredentials`](doc/auth/oauth-2-client-credentials-grant.md) | The credential object for oauthClientCredentials |

The API client can be initialized as follows:

```ts
import { Client, Environment, LogLevel } from 'folderit';

const client = new Client({
  openIdConnectCredentials: {
    accessToken: 'AccessToken'
  },
  oauthAuthorizationCodeCredentials: {
    oauthClientId: 'OAuthClientId',
    oauthClientSecret: 'OAuthClientSecret',
    oauthRedirectUri: 'OAuthRedirectUri'
  },
  oauthClientCredentialsCredentials: {
    oauthClientId: 'OAuthClientId',
    oauthClientSecret: 'OAuthClientSecret'
  },
  timeout: 0,
  environment: Environment.Production,
  logging: {
    logLevel: LogLevel.Info,
    logRequest: {
      logBody: true
    },
    logResponse: {
      logHeaders: true
    }
  },
});
```

## Authorization

This API uses the following authentication schemes.

* [`openIdConnect (OAuth 2 Bearer token)`](doc/auth/oauth-2-bearer-token.md)
* [`OAuth_authorization_code (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)
* [`OAuth_client_credentials (OAuth 2 Client Credentials Grant)`](doc/auth/oauth-2-client-credentials-grant.md)

## List of APIs

* [User](doc/controllers/user.md)
* [Account](doc/controllers/account.md)
* [Entity](doc/controllers/entity.md)
* [Folder](doc/controllers/folder.md)
* [File](doc/controllers/file.md)
* [Meta](doc/controllers/meta.md)
* [Tag](doc/controllers/tag.md)
* [Person](doc/controllers/person.md)
* [Reminder](doc/controllers/reminder.md)
* [Resolution](doc/controllers/resolution.md)
* [Workflow](doc/controllers/workflow.md)
* [Share](doc/controllers/share.md)
* [Group](doc/controllers/group.md)
* [Plan](doc/controllers/plan.md)
* [Search](doc/controllers/search.md)
* [Audit](doc/controllers/audit.md)

## SDK Infrastructure

### Configuration

* [HttpClientOptions](doc/http-client-options.md)
* [RetryConfiguration](doc/retry-configuration.md)
* [ProxySettings](doc/proxy-settings.md)
* [PartialLoggingOptions](doc/partial-logging-options.md)
* [PartialRequestLoggingOptions](doc/partial-request-logging-options.md)
* [PartialResponseLoggingOptions](doc/partial-response-logging-options.md)
* [LoggerInterface](doc/logger-interface.md)

### HTTP

* [HttpRequest](doc/http-request.md)

### Utilities

* [ApiResponse](doc/api-response.md)
* [ApiError](doc/api-error.md)

